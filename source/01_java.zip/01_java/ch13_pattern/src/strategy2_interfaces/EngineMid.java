package strategy2_interfaces;

public class EngineMid implements IEngine {

	@Override
	public void engine() {
		System.out.println("�߱޿��� �Դϴ�.");
	}

}
