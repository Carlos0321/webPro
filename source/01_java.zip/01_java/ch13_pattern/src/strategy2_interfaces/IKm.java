package strategy2_interfaces;
// 10km, km15, 20km/1�� �̿�  
public interface IKm {
	public void km();
}
