package strategy3_interfaces;

public interface Iget {
	public void get();
}
