package strategy3_interfaces;

public interface Ijob {
	public void job();
}
