package strategy3_interfaces;

public class JobLec implements Ijob {

	@Override
	public void job() {
		System.out.println("���Ǹ� �մϴ� ");
	}

}
