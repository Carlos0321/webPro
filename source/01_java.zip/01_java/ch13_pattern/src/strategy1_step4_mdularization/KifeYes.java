package strategy1_step4_mdularization;

import strategy1_step4_interfaces.Iknife;

public class KifeYes implements Iknife {

	@Override
	public void knife() {

	}

}
