package strategy1_step4_interfaces;

public interface IMissile {
	public void missile();
}
