package strategy1_step4_interfaces;

public interface IFly {
	public void fly();
}
