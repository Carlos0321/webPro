package strategy1_step4_interfaces;

public interface Iknife {
	public void knife();
}
