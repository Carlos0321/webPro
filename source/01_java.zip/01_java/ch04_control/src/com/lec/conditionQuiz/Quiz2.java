package com.lec.conditionQuiz;

public class Quiz2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1 = 27;
		int num2 = 32;
		int max;
		if (num1>num2) {
			 max = num1;
			
		}else {
			 max = num2;
		}
		System.out.println(max);
	}

}
