package com.lec.conditionQuiz;

import java.util.Scanner;

public class Practice_01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int you, computer = (int)Math.random()*3 ;
		System.out.println("����(0), ����(1), ��(2)");
		you = sc.nextInt() ; 
		
		if (you==0)
	}

}
