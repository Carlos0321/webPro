package com.lec.loop;

public class Quiz01 {

	public static void main(String[] args) {
		int tot = 1;
		for(int i=1 ; i<=10; i++) {
		 tot = tot * i;
		}
			System.out.println("1~10������ ���� " + tot);
	}

}
