package com.lec.ex11_robot;

public interface Robot {}
