package com.lec.ex11_robot;

public class DanceRobot implements Robot{
	public void dance() {
		System.out.println("���� ��ϴ� ");
	}

}
