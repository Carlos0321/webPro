package com.lec.ex11_robot;

public class SingRobot implements Robot{
	public void sing() {
		System.out.println("�뷡�� �θ��ϴ�");
	}
}
