package com.lec.ex04_actor;
//�ҹ�� 
public interface IFireFighter {
	public void outFire();
	public void saveMan();
}
