package com.lec.ex04_actor;
//�丮�� 
public interface IChef {
	public void makePizza();
	public void makeSpaghetti();
}
