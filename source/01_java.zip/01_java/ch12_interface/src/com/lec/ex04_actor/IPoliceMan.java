package com.lec.ex04_actor;

public interface IPoliceMan {
	public void canCatchCriminal();
	public void canSearch();
}
