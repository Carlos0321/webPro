package com.lec.ex10_aorb;

public class A implements I {

	@Override
	public void method() {
		System.out.println("A method");
	}

}
