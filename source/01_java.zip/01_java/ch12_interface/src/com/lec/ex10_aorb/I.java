package com.lec.ex10_aorb;

public interface I {
	public void method();
}
