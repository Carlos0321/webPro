package com.lec.ex10_aorb;

public class B implements I {

	@Override
	public void method() {
		System.out.println("B method");
	}

}
