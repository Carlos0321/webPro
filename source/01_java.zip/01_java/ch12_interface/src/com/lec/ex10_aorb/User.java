package com.lec.ex10_aorb;

public class User {
	public void use(I i) {
		i.method();
	}
}
