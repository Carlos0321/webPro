package com.lec.ex01;

public interface InterfaceEx2 {
	public String CONSTANT_STRING = "Hello World";
	public String method2(); 
	
}
