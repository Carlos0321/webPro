package com.lec.ex05_test;

public class TestMain {

	public static void main(String[] args) {
		TestChildClass obj = new TestChildClass();
		obj.m1();
		obj.m2();
		obj.m3();
		obj.m11();
		System.out.println(I11.i11);
		System.out.println(I3.i1);
		System.out.println(I1.i1);
	}

}
