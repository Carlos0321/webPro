package com.lec.ex05_test;
// i1 i2 m1() m2()
public interface I3 extends I1, I2 {
	public int i3 = 3;
	public void m3();
	
}
