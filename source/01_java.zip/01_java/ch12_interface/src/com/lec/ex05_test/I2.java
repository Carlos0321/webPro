package com.lec.ex05_test;

public interface I2 {
	public int i2 = 2;
	public void m2();
}
