package com.lec.ex05_test;

public interface I1 {		
	public int i1 = 1;
	public void m1(); //�޼ҵ� 
}
