package com.lec.ex;
// ��Ʈ������ (& |)
public class Ex05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 3; // 0 0 1 1
		int j = 1; // 0 0 0 1
		System.out.println(i|j);
	}

}
