package com.lec.ex2_human;

public class ManTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Man kim = new Man() ;
		Man kang = new Man(22, 165, 60.5);
		Man mooon = new Man(22, 165, 60.5,"010-9999-9999");
		
		Man yi = new Man(22);
		
	}

}
