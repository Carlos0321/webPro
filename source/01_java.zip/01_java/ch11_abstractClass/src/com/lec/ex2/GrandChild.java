package com.lec.ex2;

public class GrandChild extends ChildClass2 {

	@Override
	public void method1() {
		System.out.println("GrandChild�� method1");
	}

}
