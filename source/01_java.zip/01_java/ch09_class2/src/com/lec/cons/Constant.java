package com.lec.cons;

public class Constant {
	public static final int HOURLYPARKINGRATE = 2000;
	public static final double PI = 3.141592653589793;
}
