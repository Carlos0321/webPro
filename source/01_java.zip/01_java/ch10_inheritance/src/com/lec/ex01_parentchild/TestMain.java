package com.lec.ex01_parentchild;

public class TestMain {

	public static void main(String[] args) {
		ChildClass child = new ChildClass();
		child.getMamaName();
		child.getPapaName();
		System.out.println(child.pStr);
	}

}
