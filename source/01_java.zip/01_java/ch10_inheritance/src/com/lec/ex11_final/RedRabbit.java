package com.lec.ex11_final;

public class RedRabbit extends Rabbit { //final class Rabit ��� x

}
