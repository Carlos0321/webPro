package com.lec.homwork;

public class Ex {

	public static void main(String[] args) {
		int korean = 90;
		int english = 100;
		int math = 85;
		
		System.out.println("korean="+ korean);
		System.out.println("english="+english);
		System.out.println("math="+math);
		
		int total = korean + english + math;
		System.out.println(total);
		
		double average = total/3.0;		
		System.out.println((korean + english + math) / 3);
		System.out.println(average);
	}
// 

	int kor = 99;
	int math = 100;
	int eng = 99;
	int sum = kor + math + eng;
	double avg = sum/3.0 ;
    
}
