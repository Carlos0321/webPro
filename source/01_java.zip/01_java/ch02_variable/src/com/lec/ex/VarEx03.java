package com.lec.ex;

public class VarEx03 {

	public static void main(String[] args) {
		System.out.println("���α׷� ���� ");
//		System.out.println(i);
		int i = 10;
		System.out.println(i);
	}

}
